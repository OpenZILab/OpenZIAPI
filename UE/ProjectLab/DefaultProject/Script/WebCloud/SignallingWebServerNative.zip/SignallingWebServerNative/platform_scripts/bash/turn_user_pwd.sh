#!/bin/bash
# Copyright Epic Games, Inc. All Rights Reserved.

# Plain text TURN setup
turnusername="PixelStreamingUser"
turnpassword="AnotherTURNintheroad"

